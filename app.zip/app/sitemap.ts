import type { MetadataRoute } from "next";
import { createClient } from "@/lib/supabase/server";

// Must match the real production domain — this was previously
// "https://prophezy.app" (not this project's domain), which meant every
// URL Google indexed from the sitemap pointed at a domain that isn't
// actually served by this app.
const SITE_URL = "https://www.prophezy.online";

const STATIC_ROUTES = [
  "",
  "/about",
  "/careers",
  "/blog",
  "/docs",
  "/support",
  "/status",
  "/legal/privacy",
  "/legal/terms",
  "/legal/cookies",
  "/legal/ai-usage",
  "/legal/data-retention",
  "/legal/acceptable-use",
];

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticEntries: MetadataRoute.Sitemap = STATIC_ROUTES.map((path) => ({
    url: `${SITE_URL}${path}`,
    lastModified: new Date(),
  }));

  try {
    const supabase = await createClient();
    const { data } = await supabase
      .from("blog_posts")
      .select("slug, published_at")
      .eq("status", "published");

    const postEntries: MetadataRoute.Sitemap = (data ?? []).map((p) => ({
      url: `${SITE_URL}/blog/${p.slug}`,
      lastModified: p.published_at ? new Date(p.published_at) : new Date(),
    }));

    return [...staticEntries, ...postEntries];
  } catch {
    // If Supabase isn't reachable at build time, still ship the static routes.
    return staticEntries;
  }
}
